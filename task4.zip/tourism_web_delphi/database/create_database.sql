IF DB_ID(N'TourismWebDB') IS NULL
BEGIN
    CREATE DATABASE TourismWebDB;
END;
GO

USE TourismWebDB;
GO

IF OBJECT_ID(N'dbo.TourOrders', N'U') IS NOT NULL DROP TABLE dbo.TourOrders;
IF OBJECT_ID(N'dbo.Tours', N'U') IS NOT NULL DROP TABLE dbo.Tours;
IF OBJECT_ID(N'dbo.Countries', N'U') IS NOT NULL DROP TABLE dbo.Countries;
GO

CREATE TABLE dbo.Countries
(
    CountryID INT IDENTITY(1, 1) NOT NULL,
    CountryName NVARCHAR(100) NOT NULL,
    VisaRequired BIT NOT NULL
        CONSTRAINT DF_Countries_VisaRequired DEFAULT (0),

    CONSTRAINT PK_Countries
        PRIMARY KEY (CountryID),

    CONSTRAINT UQ_Countries_CountryName
        UNIQUE (CountryName)
);
GO

CREATE TABLE dbo.Tours
(
    TourID INT IDENTITY(1, 1) NOT NULL,
    CountryID INT NOT NULL,
    TourName NVARCHAR(150) NOT NULL,
    StartDate DATE NOT NULL,
    Nights INT NOT NULL,
    BasePrice DECIMAL(12, 2) NOT NULL,

    CONSTRAINT PK_Tours
        PRIMARY KEY (TourID),

    CONSTRAINT FK_Tours_Countries
        FOREIGN KEY (CountryID)
        REFERENCES dbo.Countries (CountryID),

    CONSTRAINT CK_Tours_Nights
        CHECK (Nights > 0),

    CONSTRAINT CK_Tours_BasePrice
        CHECK (BasePrice >= 0)
);
GO

CREATE TABLE dbo.TourOrders
(
    OrderID INT IDENTITY(1, 1) NOT NULL,
    TourID INT NOT NULL,
    CustomerName NVARCHAR(150) NOT NULL,
    Email NVARCHAR(150) NOT NULL,
    Persons INT NOT NULL,
    TotalPrice DECIMAL(12, 2) NOT NULL,
    Status NVARCHAR(30) NOT NULL
        CONSTRAINT DF_TourOrders_Status DEFAULT (N'Новый'),
    CreatedAt DATETIME2(0) NOT NULL
        CONSTRAINT DF_TourOrders_CreatedAt DEFAULT (SYSDATETIME()),

    CONSTRAINT PK_TourOrders
        PRIMARY KEY (OrderID),

    CONSTRAINT FK_TourOrders_Tours
        FOREIGN KEY (TourID)
        REFERENCES dbo.Tours (TourID),

    CONSTRAINT CK_TourOrders_Persons
        CHECK (Persons BETWEEN 1 AND 20),

    CONSTRAINT CK_TourOrders_TotalPrice
        CHECK (TotalPrice >= 0),

    CONSTRAINT CK_TourOrders_Status
        CHECK (Status IN
        (
            N'Новый',
            N'Подтвержден',
            N'Оплачен',
            N'Завершен',
            N'Отменен'
        ))
);
GO

CREATE INDEX IX_Tours_CountryID
    ON dbo.Tours (CountryID);

CREATE INDEX IX_TourOrders_TourID
    ON dbo.TourOrders (TourID);

CREATE INDEX IX_TourOrders_Status
    ON dbo.TourOrders (Status);

CREATE INDEX IX_TourOrders_CreatedAt
    ON dbo.TourOrders (CreatedAt DESC);
GO

INSERT INTO dbo.Countries (CountryName, VisaRequired)
VALUES
    (N'Россия', 0),
    (N'Турция', 0),
    (N'Египет', 1),
    (N'Италия', 1);
GO

INSERT INTO dbo.Tours
(
    CountryID,
    TourName,
    StartDate,
    Nights,
    BasePrice
)
VALUES
    (1, N'Сочи: море и горы', '2026-08-15', 7, 58000.00),
    (2, N'Анталья: пляжный отдых', '2026-09-01', 10, 92000.00),
    (3, N'Хургада: Красное море', '2026-10-05', 8, 87000.00),
    (4, N'Рим и Флоренция', '2026-10-20', 7, 135000.00);
GO

INSERT INTO dbo.TourOrders
(
    TourID,
    CustomerName,
    Email,
    Persons,
    TotalPrice,
    Status
)
VALUES
    (2, N'Иванов Иван Иванович', N'ivanov@example.com', 2, 184000.00, N'Оплачен'),
    (1, N'Петрова Анна Сергеевна', N'petrova@example.com', 1, 58000.00, N'Подтвержден');
GO

SELECT
    o.OrderID,
    o.CustomerName,
    o.Email,
    c.CountryName,
    t.TourName,
    o.Persons,
    o.TotalPrice,
    o.Status,
    o.CreatedAt
FROM dbo.TourOrders AS o
INNER JOIN dbo.Tours AS t
    ON t.TourID = o.TourID
INNER JOIN dbo.Countries AS c
    ON c.CountryID = t.CountryID
ORDER BY o.OrderID;
GO
