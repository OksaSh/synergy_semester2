# Tourism Web — Delphi WebBroker + IIS + MS SQL Server

Учебное WEB-приложение туристического агентства для кейс-задачи № 4.

## Возможности

- главная страница;
- просмотр заказов;
- создание нового заказа;
- расчет стоимости тура на стороне сервера;
- проверочный маршрут `/health`;
- хранение данных в Microsoft SQL Server;
- параметризованные SQL-запросы;
- обработка ошибок и страницы 404.

## Технологии

- Delphi 10.2;
- WebBroker;
- ISAPI;
- Microsoft IIS;
- Microsoft SQL Server;
- ADO / Microsoft OLE DB Driver for SQL Server.

## Структура репозитория

```text
TourismWeb.dpr
src/
  WebModuleUnit.pas
  WebModuleUnit.dfm
database/
  create_database.sql
config/
  connection_string.txt
docs/
  market_analysis.md
  report_text.md
```

## 1. Создание базы данных

1. Открыть SQL Server Management Studio.
2. Подключиться к локальному экземпляру SQL Server.
3. Открыть `database/create_database.sql`.
4. Выполнить скрипт.
5. Убедиться, что создана база `TourismWebDB`.

## 2. Настройка строки подключения

Отредактировать файл:

```text
config/connection_string.txt
```

Пример для SQL Server Express:

```text
Provider=MSOLEDBSQL;Data Source=localhost\SQLEXPRESS;Initial Catalog=TourismWebDB;Integrated Security=SSPI;
```

При использовании другого экземпляра SQL Server заменить значение
`Data Source`.

## 3. Сборка в Delphi 10.2

1. Открыть `TourismWeb.dpr`.
2. Проверить платформу Win32 или Win64 в зависимости от пула IIS.
3. Выполнить `Project → Build`.
4. В результате будет создан файл `TourismWeb.dll`.

Разрядность DLL должна совпадать с настройкой пула приложений IIS.

## 4. Развертывание в IIS

1. Включить компоненты IIS:
   - Web Server;
   - Application Development;
   - ISAPI Extensions;
   - ISAPI Filters.
2. Создать каталог, например:

```text
C:\inetpub\wwwroot\tourism
```

3. Скопировать в каталог:
   - `TourismWeb.dll`;
   - файл `connection_string.txt` из папки `config`.
4. Создать отдельный пул приложений.
5. Установить для пула:
   - Managed pipeline: Classic;
   - .NET CLR version: No Managed Code;
   - разрядность в соответствии со сборкой DLL.
6. Создать приложение IIS, указывающее на каталог `tourism`.
7. Разрешить выполнение ISAPI DLL.
8. Добавить сопоставление обработчика `*.dll` с модулем `IsapiModule`.
9. Предоставить учетной записи пула право подключения к базе `TourismWebDB`.

## 5. Запуск

Адрес зависит от имени сайта и виртуального каталога. Пример:

```text
http://localhost/tourism/TourismWeb.dll/
```

Маршруты:

```text
/                  главная страница
/orders            список заказов
/orders/new        форма создания заказа
/health            контрольный JSON-ответ
```

## 6. Проверка

Открыть:

```text
http://localhost/tourism/TourismWeb.dll/health
```

Ожидаемый ответ:

```json
{"status":"ok","application":"TourismWeb"}
```

## Примечание

Для публикации в рабочей среде необходимо включить HTTPS, ограничить права
учетной записи пула IIS и хранить строку подключения в защищенной конфигурации.
