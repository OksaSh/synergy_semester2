library TourismWeb;

uses
  Web.Win.ISAPIApp,
  Web.WebBroker,
  WebModuleUnit in 'src\WebModuleUnit.pas' {WebModule1: TWebModule};

{$R *.res}

exports
  GetExtensionVersion,
  HttpExtensionProc,
  TerminateExtension;

begin
  Application.Initialize;
  Application.WebModuleClass := WebModuleClass;
  Application.Run;
end.
