unit WebModuleUnit;

interface

uses
  System.SysUtils,
  System.Classes,
  Data.DB,
  Data.Win.ADODB,
  Web.HTTPApp;

type
  TWebModule1 = class(TWebModule)
    procedure WebModuleCreate(Sender: TObject);
    procedure WebModuleDestroy(Sender: TObject);
    procedure WebModule1DefaultHandlerAction(
      Sender: TObject;
      Request: TWebRequest;
      Response: TWebResponse;
      var Handled: Boolean);
  private
    FConnection: TADOConnection;

    function ApplicationDirectory: string;
    function LoadConnectionString: string;
    function HtmlEncode(const Value: string): string;
    function Page(const Title, Body: string): string;
    function RenderHome: string;
    function RenderOrders: string;
    function RenderNewOrderForm: string;

    procedure CreateOrder(
      const CustomerName: string;
      const Email: string;
      TourID: Integer;
      Persons: Integer);
  end;

var
  WebModuleClass: TComponentClass = TWebModule1;

implementation

{%CLASSGROUP 'System.Classes.TPersistent'}

{$R *.dfm}

function TWebModule1.ApplicationDirectory: string;
begin
  Result := IncludeTrailingPathDelimiter(
    ExtractFilePath(GetModuleName(HInstance)));
end;

function TWebModule1.LoadConnectionString: string;
var
  FileName: string;
  Lines: TStringList;
begin
  FileName := ApplicationDirectory + 'connection_string.txt';

  if not FileExists(FileName) then
    Exit(
      'Provider=MSOLEDBSQL;' +
      'Data Source=localhost\SQLEXPRESS;' +
      'Initial Catalog=TourismWebDB;' +
      'Integrated Security=SSPI;');

  Lines := TStringList.Create;
  try
    Lines.LoadFromFile(FileName, TEncoding.UTF8);
    Result := Trim(Lines.Text);
  finally
    Lines.Free;
  end;
end;

procedure TWebModule1.WebModuleCreate(Sender: TObject);
begin
  FConnection := TADOConnection.Create(nil);
  FConnection.LoginPrompt := False;
  FConnection.ConnectionString := LoadConnectionString;
  FConnection.Connected := True;
end;

procedure TWebModule1.WebModuleDestroy(Sender: TObject);
begin
  FreeAndNil(FConnection);
end;

function TWebModule1.HtmlEncode(const Value: string): string;
begin
  Result := StringReplace(Value, '&', '&amp;', [rfReplaceAll]);
  Result := StringReplace(Result, '<', '&lt;', [rfReplaceAll]);
  Result := StringReplace(Result, '>', '&gt;', [rfReplaceAll]);
  Result := StringReplace(Result, '"', '&quot;', [rfReplaceAll]);
  Result := StringReplace(Result, '''', '&#39;', [rfReplaceAll]);
end;

function TWebModule1.Page(const Title, Body: string): string;
begin
  Result :=
    '<!doctype html>' +
    '<html lang="ru">' +
    '<head>' +
      '<meta charset="utf-8">' +
      '<meta name="viewport" content="width=device-width, initial-scale=1">' +
      '<title>' + HtmlEncode(Title) + '</title>' +
      '<style>' +
        'body{font-family:Arial,sans-serif;margin:0;background:#f4f6f8;color:#1d2733}' +
        'header{background:#1558a6;color:white;padding:18px 28px}' +
        'nav a{color:white;margin-right:18px;text-decoration:none;font-weight:bold}' +
        'main{max-width:1100px;margin:28px auto;background:white;padding:28px;' +
             'border-radius:10px;box-shadow:0 3px 16px rgba(0,0,0,.08)}' +
        'table{width:100%;border-collapse:collapse;margin-top:18px}' +
        'th,td{border:1px solid #d9e0e7;padding:10px;text-align:left}' +
        'th{background:#eef4fb}' +
        'label{display:block;margin-top:14px;font-weight:bold}' +
        'input,select{width:100%;box-sizing:border-box;padding:10px;margin-top:5px;' +
                     'border:1px solid #b8c3cf;border-radius:5px}' +
        'button,.button{display:inline-block;margin-top:18px;padding:10px 18px;' +
                       'background:#1558a6;color:white;border:0;border-radius:5px;' +
                       'text-decoration:none;cursor:pointer}' +
        '.notice{padding:12px;background:#eef7ee;border-left:4px solid #2b8a3e}' +
        '.error{padding:12px;background:#fff0f0;border-left:4px solid #c92a2a}' +
      '</style>' +
    '</head>' +
    '<body>' +
      '<header>' +
        '<h1>Tourism Web</h1>' +
        '<nav>' +
          '<a href="./">Главная</a>' +
          '<a href="./orders">Заказы</a>' +
          '<a href="./orders/new">Новый заказ</a>' +
          '<a href="./health">Проверка</a>' +
        '</nav>' +
      '</header>' +
      '<main>' + Body + '</main>' +
    '</body>' +
    '</html>';
end;

function TWebModule1.RenderHome: string;
begin
  Result := Page(
    'Главная',
    '<h2>Информационная система туристического агентства</h2>' +
    '<p>Приложение демонстрирует WEB-архитектуру на базе Delphi WebBroker, ' +
    'Microsoft IIS и Microsoft SQL Server.</p>' +
    '<p>Реализованы просмотр заказов, создание нового заказа и проверка ' +
    'доступности приложения.</p>' +
    '<a class="button" href="./orders">Открыть список заказов</a>');
end;

function TWebModule1.RenderOrders: string;
var
  Query: TADOQuery;
  Rows: TStringBuilder;
begin
  Query := TADOQuery.Create(nil);
  Rows := TStringBuilder.Create;
  try
    Query.Connection := FConnection;
    Query.SQL.Text :=
      'SELECT o.OrderID, o.CustomerName, o.Email, ' +
      '       t.TourName, c.CountryName, o.Persons, ' +
      '       o.TotalPrice, o.Status, o.CreatedAt ' +
      'FROM dbo.TourOrders o ' +
      'INNER JOIN dbo.Tours t ON t.TourID = o.TourID ' +
      'INNER JOIN dbo.Countries c ON c.CountryID = t.CountryID ' +
      'ORDER BY o.OrderID DESC';
    Query.Open;

    while not Query.Eof do
    begin
      Rows.Append('<tr>');
      Rows.Append('<td>' + Query.FieldByName('OrderID').AsString + '</td>');
      Rows.Append('<td>' +
        HtmlEncode(Query.FieldByName('CustomerName').AsString) + '</td>');
      Rows.Append('<td>' +
        HtmlEncode(Query.FieldByName('Email').AsString) + '</td>');
      Rows.Append('<td>' +
        HtmlEncode(Query.FieldByName('TourName').AsString) + '</td>');
      Rows.Append('<td>' +
        HtmlEncode(Query.FieldByName('CountryName').AsString) + '</td>');
      Rows.Append('<td>' + Query.FieldByName('Persons').AsString + '</td>');
      Rows.Append('<td>' +
        FormatFloat('0.00', Query.FieldByName('TotalPrice').AsFloat) +
        ' руб.</td>');
      Rows.Append('<td>' +
        HtmlEncode(Query.FieldByName('Status').AsString) + '</td>');
      Rows.Append('<td>' +
        HtmlEncode(Query.FieldByName('CreatedAt').AsString) + '</td>');
      Rows.Append('</tr>');

      Query.Next;
    end;

    Result := Page(
      'Заказы',
      '<h2>Заказы туров</h2>' +
      '<a class="button" href="./orders/new">Оформить заказ</a>' +
      '<table>' +
        '<thead><tr>' +
          '<th>ID</th><th>Клиент</th><th>Email</th><th>Тур</th>' +
          '<th>Страна</th><th>Туристы</th><th>Стоимость</th>' +
          '<th>Статус</th><th>Создан</th>' +
        '</tr></thead>' +
        '<tbody>' + Rows.ToString + '</tbody>' +
      '</table>');
  finally
    Rows.Free;
    Query.Free;
  end;
end;

function TWebModule1.RenderNewOrderForm: string;
var
  Query: TADOQuery;
  Options: TStringBuilder;
begin
  Query := TADOQuery.Create(nil);
  Options := TStringBuilder.Create;
  try
    Query.Connection := FConnection;
    Query.SQL.Text :=
      'SELECT t.TourID, t.TourName, c.CountryName, t.BasePrice ' +
      'FROM dbo.Tours t ' +
      'INNER JOIN dbo.Countries c ON c.CountryID = t.CountryID ' +
      'ORDER BY c.CountryName, t.TourName';
    Query.Open;

    while not Query.Eof do
    begin
      Options.Append(
        '<option value="' + Query.FieldByName('TourID').AsString + '">' +
        HtmlEncode(Query.FieldByName('CountryName').AsString) + ' — ' +
        HtmlEncode(Query.FieldByName('TourName').AsString) + ' — ' +
        FormatFloat('0.00', Query.FieldByName('BasePrice').AsFloat) +
        ' руб. за человека</option>');
      Query.Next;
    end;

    Result := Page(
      'Новый заказ',
      '<h2>Оформление заказа</h2>' +
      '<form method="post" action="./orders/create">' +
        '<label for="customer_name">ФИО клиента</label>' +
        '<input id="customer_name" name="customer_name" required maxlength="150">' +

        '<label for="email">Электронная почта</label>' +
        '<input id="email" type="email" name="email" required maxlength="150">' +

        '<label for="tour_id">Тур</label>' +
        '<select id="tour_id" name="tour_id" required>' +
          Options.ToString +
        '</select>' +

        '<label for="persons">Количество туристов</label>' +
        '<input id="persons" type="number" name="persons" min="1" max="20" value="1" required>' +

        '<button type="submit">Создать заказ</button>' +
      '</form>');
  finally
    Options.Free;
    Query.Free;
  end;
end;

procedure TWebModule1.CreateOrder(
  const CustomerName: string;
  const Email: string;
  TourID: Integer;
  Persons: Integer);
var
  Query: TADOQuery;
begin
  if Trim(CustomerName) = '' then
    raise Exception.Create('Не указано имя клиента.');

  if Trim(Email) = '' then
    raise Exception.Create('Не указана электронная почта.');

  if TourID <= 0 then
    raise Exception.Create('Не выбран тур.');

  if (Persons < 1) or (Persons > 20) then
    raise Exception.Create('Количество туристов должно быть от 1 до 20.');

  Query := TADOQuery.Create(nil);
  try
    Query.Connection := FConnection;
    Query.SQL.Text :=
      'INSERT INTO dbo.TourOrders ' +
      '  (TourID, CustomerName, Email, Persons, TotalPrice, Status) ' +
      'SELECT TourID, :CustomerName, :Email, :Persons, ' +
      '       BasePrice * :PersonsForPrice, N''Новый'' ' +
      'FROM dbo.Tours ' +
      'WHERE TourID = :TourID';

    Query.Parameters.ParamByName('CustomerName').Value := Trim(CustomerName);
    Query.Parameters.ParamByName('Email').Value := Trim(Email);
    Query.Parameters.ParamByName('Persons').Value := Persons;
    Query.Parameters.ParamByName('PersonsForPrice').Value := Persons;
    Query.Parameters.ParamByName('TourID').Value := TourID;

    Query.ExecSQL;

    if Query.RowsAffected <> 1 then
      raise Exception.Create('Выбранный тур не найден.');
  finally
    Query.Free;
  end;
end;

procedure TWebModule1.WebModule1DefaultHandlerAction(
  Sender: TObject;
  Request: TWebRequest;
  Response: TWebResponse;
  var Handled: Boolean);
var
  Path: string;
  TourID: Integer;
  Persons: Integer;
begin
  Handled := True;
  Response.ContentType := 'text/html; charset=utf-8';

  try
    Path := LowerCase(Request.PathInfo);

    if (Path = '') or (Path = '/') then
      Response.Content := RenderHome

    else if (Path = '/health') then
    begin
      Response.ContentType := 'application/json; charset=utf-8';
      Response.Content := '{"status":"ok","application":"TourismWeb"}';
    end

    else if (Path = '/orders') and SameText(Request.Method, 'GET') then
      Response.Content := RenderOrders

    else if (Path = '/orders/new') and SameText(Request.Method, 'GET') then
      Response.Content := RenderNewOrderForm

    else if (Path = '/orders/create') and SameText(Request.Method, 'POST') then
    begin
      TourID := StrToIntDef(Request.ContentFields.Values['tour_id'], 0);
      Persons := StrToIntDef(Request.ContentFields.Values['persons'], 0);

      CreateOrder(
        Request.ContentFields.Values['customer_name'],
        Request.ContentFields.Values['email'],
        TourID,
        Persons);

      Response.StatusCode := 302;
      Response.SetCustomHeader('Location', './orders');
      Response.Content := '';
    end

    else
    begin
      Response.StatusCode := 404;
      Response.Content := Page(
        'Страница не найдена',
        '<div class="error"><strong>Ошибка 404.</strong> ' +
        'Запрошенная страница не найдена.</div>');
    end;
  except
    on E: Exception do
    begin
      Response.StatusCode := 500;
      Response.Content := Page(
        'Ошибка приложения',
        '<div class="error"><strong>Ошибка:</strong> ' +
        HtmlEncode(E.Message) + '</div>');
    end;
  end;
end;

end.
